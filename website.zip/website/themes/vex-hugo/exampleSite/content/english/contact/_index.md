---
title: "Book Bertha Tobias"
description : "this is a meta description"

office:
  title : "Book Bertha Tobias"
  mobile : "+264 81 242 4022"
  email : "hello@berthatobias.com"
  location : "Windhoek, Namibia"
  content : "Please contact me using the details below"

# opennig hour

    
draft: false
---