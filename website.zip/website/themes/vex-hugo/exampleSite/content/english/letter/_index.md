---
title: "A LETTER TO MY YOUNGER SELF"
description : "this is a meta description"
draft: false
---
### Dear younger Bertha,

As you write this, you are seated in the warm glow of the midday sun, sipping on spicy ginger honey tea and, as always, strategizing for world domination. You’ve come so far, and I’m proud of you. You have learned to consistently fold up your fears in service of your dreams.

Along the way, you’ve learned these important lessons:


1) Everything you need to survive is already inside of you. Understand that you have the social and emotional tools to navigate your way through anything and everything. So stop waiting. Nobody is coming to save you. You are the hero you’ve been waiting for.
2) You are allowed to, supposed to, write your own story.
The most dangerous thing you can possibly do is leave your destiny in the hands of externally defined parameters. The relentlessness with which you set and pursue your intentions should be informed by the deepest desires of your heart. Nobody knows those desires better than you do. Let them guide you.
3) Your best is better than you think. As always, you’ve given it your all, and it has paid off. When you felt like abandoning school abroad to come back home to the comfort of familiarity, you braced the crippling sense of inadequacy and gave it your best anyway. It’s paid off. Your relentless dedication to always giving life your all pays off in the end.
4) Shredding yourself down to bite-sized pieces to make yourself more digestible is an injustice to both you and the world. There will be inevitable opposition to a force which actively acknowledges its power. Show up anyway. Speak anyway. Dare anyway.
5) Your destination will always feel familiar. Contrary to popular belief, you usually had no idea what you were doing. The specificities of your action plan weren’t clear, but the destination always was. You are able to feel it when something aligns with your innermost ambitions. Likewise, you are able to feel it when something doesn’t. Lean in to the quiet whisper of your brilliance.

Above all else, I hope that you stay curious about the world and about yourself. I hope you continue to do everything out of your regard for humanity and your ever-burning passion to do life big. I hope you continue to honour your evolution.

I wish you nothing but continued excellence and the remembrance that you only ever get what you have the courage to ask for.

Yours in all things magical!

Your ever evolving elder self,

Bertha Tobias