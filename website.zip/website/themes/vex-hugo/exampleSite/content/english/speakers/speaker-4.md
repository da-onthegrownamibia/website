---
title: "Event Title"
date: 2019-10-17T11:22:16+06:00
images: 
  - "images/showcase/speaker-4.jpg"
  - "images/showcase/speaker-2.jpg"
  - "images/showcase/speaker-3.jpg"
  - "images/showcase/speaker-1.jpg"
  - "images/showcase/speaker-5.jpg"
  - "images/showcase/speaker-6.jpg"

# meta description
description : "this is meta description"


draft: false
---
More information about this event
